#parse("C File Header.h")
#pragma once

${NAMESPACES_OPEN}

class ${NAME} {
    ${NAME}();
    ~${NAME}();
};

${NAMESPACES_CLOSE}

