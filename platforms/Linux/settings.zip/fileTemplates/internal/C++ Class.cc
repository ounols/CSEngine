#parse("C File Header.h")
#[[#include]]# "${HEADER_FILENAME}"

${NAME}::${NAME}() {

}

${NAME}::~${NAME}() {

}